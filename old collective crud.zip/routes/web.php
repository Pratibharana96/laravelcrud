<?php
Use App\link;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
///////////////////////////////Pratibha's Github Data/////////////////////////////////////////
//get all table data
Route::get('pratibha','PratibhaController@index');
// edit a record y id
Route::get('/prdata/{prdata?}','PratibhaController@edit');
//save a record
Route::post('/prdata','PratibhaController@save');
//update a record
Route::put('/prdata/{prdata?}','PratibhaController@update');
//delete a record
Route::delete('/prdata/{prdata?}','PratibhaController@delete');

//view
// Route::get('/','HomeController@index');
// //add
// Route::post('/ajaxRequest','HomeController@ajaxRequestPost');
// //edit
// //Route::get('/item/{item?}','HomeController@edit');
//--CREATE a link--//

/////////////////////////////////////////////////////////links//////////////////////////////////////////

//--LOAD THE VIEW--//
Route::get('/', function () {
    $links = Link::all();
    return view('laracrud')->with('links', $links);
});
 
//--CREATE a link--//
Route::post('/links', function (Request $request) {
    $link = Link::create($request->all());
    return Response::json($link);
});
 
//--GET LINK TO EDIT--//
Route::get('/links/{link_id?}', function ($link_id) {
    $link = Link::find($link_id);
    return Response::json($link);
});
 
//--UPDATE a link--//
Route::put('/links/{link_id?}', function (Request $request, $link_id) {
    $link = Link::find($link_id);
    $link->url = $request->url;
    $link->description = $request->description;
    $link->save();
    return Response::json($link);
});
 
//--DELETE a link--//
Route::delete('/links/{link_id?}', function ($link_id) {
    $link = Link::destroy($link_id);
    return Response::json($link);
});