<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pratibha extends Model
{
    protected $table= 'pratibhas';
protected $fillable =['name','designation','githublink'];
}
