<?php

namespace App\Http\Controllers;

use App\Home;
use Illuminate\Http\Request;
use View;
class HomeController extends Controller
{
	
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxRequestPost(Request $request)
    {
		$model= new Home;
		$model->name = $request->name;
		$model->email = $request->email;
		$model->password = $request->password;
		$model->save();
  
		//dd($input);exit;

        return response()->json(['success'=>'Got Simple Ajax Request.']);
    }
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $member= Home::all();
        //dd($member);exit;
        return View::make('welcome', compact('member'));

       // return view ('welcome')->withData ($member);
       // return view('welcome')->with('member',$member);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Home  $home
     * @return \Illuminate\Http\Response
     */
    public function show(Home $home)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Home  $home
     * @return \Illuminate\Http\Response
     */
    public function edit(Item $item)
    {
        

     $itemedit = App\Home::find($item);
    // / dd($itemedit);exit;
     return response()->json($itemedit);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Home  $home
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Home $home)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Home  $home
     * @return \Illuminate\Http\Response
     */
    public function destroy(Home $home)
    {
        //
    }
}
